window.onload = botones;

var x = 0;

function botones() {

    document.getElementById("annadir").addEventListener("click", agregar);

}

function agregar() {

    x++

    var nombre    = document.getElementById("nombre").value;
    var apellidos = document.getElementById("apellidos").value;
    var curso     = document.getElementById("curso").value;

    if(nombre == "" || apellidos == "" || curso == "") {

        alert("Rellena todos los campos");

    } else {

        var pattern = new RegExp("^[a-zA-Z áéíóúÁÉÍÓÚª]+$");

        if(pattern.test(nombre) && pattern.test(apellidos)) {

            var tabla = document.getElementById("registros");
            var fila = document.createElement("tr");
            var celda1 = document.createElement("td");
            var celda2 = document.createElement("td");
            var celda3 = document.createElement("td");
            var celda4 = document.createElement("td");
            var celda5 = document.createElement("td");

            tabla.appendChild(fila);
            fila.appendChild(celda1);
            celda1.innerHTML = x;
            fila.appendChild(celda2);
            celda2.innerHTML = nombre;
            fila.appendChild(celda3);
            celda3.innerHTML = apellidos;
            fila.appendChild(celda4);
            celda4.innerHTML = curso;
            fila.appendChild(celda5);
            celda5.innerHTML = "<button onclick='eliminar(this)'>Borrar solicitud</button>";

        } else {
                
            alert("El nombre y los apellidos no pueden contener números");

        }
    
    }

}

function eliminar( alumno ) {

    console.log(alumno.parentNode.parentNode)

    var fila = alumno.parentNode.parentNode;
    fila.parentNode.removeChild(fila);

}